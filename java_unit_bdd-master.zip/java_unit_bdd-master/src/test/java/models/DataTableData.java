package models;

import lombok.Getter;

@Getter
public class DataTableData {
    private Double expectedDueSum;
}
