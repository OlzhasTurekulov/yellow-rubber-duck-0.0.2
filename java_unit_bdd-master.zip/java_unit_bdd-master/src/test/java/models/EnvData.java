package models;

import lombok.Getter;

@Getter
public class EnvData {
    private String host;
    private int wait;
}
