package hooks;

public class Hooks {
    // todo: add hooks for pre and post conditions
}
